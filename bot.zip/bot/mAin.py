import time
import hmac
import hashlib
import base64
import requests

OKX_API_KEY = "fd15e419-0838-4b1e-9ddd-6212294f765e"
OKX_API_SECRET = "9DF900F8E676B4110F6A4A1305CED7F2"
OKX_API_PASSPHRASE = "BlackPlatypus10$"

def fetch_okx_balance():
    url = "https://www.okx.com/api/v5/account/balance"
    request_path = "/api/v5/account/balance"
    query_string = "ccy=USDT"
    method = "GET"
    body = ""
    timestamp = time.strftime('%Y-%m-%dT%H:%M:%S', time.gmtime()) + ".000Z"
    message = f"{timestamp}{method}{request_path}?{query_string}{body}"
    signature = base64.b64encode(
        hmac.new(
            OKX_API_SECRET.encode('utf-8'),
            message.encode('utf-8'),
            hashlib.sha256
        ).digest()
    ).decode()
    headers = {
        'OK-ACCESS-KEY': OKX_API_KEY,
        'OK-ACCESS-SIGN': signature,
        'OK-ACCESS-TIMESTAMP': timestamp,
        'OK-ACCESS-PASSPHRASE': OKX_API_PASSPHRASE
    }
    resp = requests.get(url, headers=headers, params={"ccy": "USDT"})
    print("Status code:", resp.status_code)
    print("Response:", resp.text)

if __name__ == "__main__":
    fetch_okx_balance()